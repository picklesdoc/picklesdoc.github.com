﻿function getTagsAndFeatureAndScenarioNames(json) {
    return _.union(
        getFeatureAndScenarioTags(json), 
        getFeatureAndScenarioNames(json),
        getStepNames(json),
        getBackgroundStuff(json));
}

function getUniqueSorted(array){
    return _.uniq(array).sort();
}

function getFeatureAndScenarioTags(json) {
    var tags = new Array();

    $.each(json, function (key, scenario) {
        $.merge(tags, scenario.Feature.Tags);
        
        $.each(scenario.Feature.FeatureElements, function (fKey, feature) {
            $.merge(tags, feature.Tags);
        });
    });

    return getUniqueSorted(tags);
}

function getFeatureAndScenarioNames(json) {
    var names = new Array();

    $.each(json, function (key, scenario) {
        $.each(scenario.Feature.FeatureElements, function (fKey, feature) {
            names.push(feature.Name);
        });
    });
    
    $.each(json, function (key, scenario) {
        names.push(scenario.Feature.Name);
    });

    return getUniqueSorted(names);
}

function getStepNames(json) {
    var names = new Array();

    $.each(json, function (key, scenario) {
        $.each(scenario.Feature.FeatureElements, function (fKey, feature) {
            $.each(feature.Steps, function (stepKey, step) {
                names.push(step.Name);
            });
        });
    });

    return getUniqueSorted(names);
}

function getBackgroundStuff(json){
    var names = new Array();

    $.each(json, function (key, scenario) {
        if(scenario.Feature.Background){

            var background = scenario.Feature.Background;

            names.push(background.Name);
            names.push(background.Description);         

            $.each(background.Steps, function (stepKey, step) {
                names.push(step.Name);
            });

            $.merge(names, scenario.Feature.Tags);            
        }
    });

    return getUniqueSorted(names);
}