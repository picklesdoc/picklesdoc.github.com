﻿function logSomething(somethingInteresting) {
    if (typeof console != 'undefined') {
        console.log(somethingInteresting);
    }
}